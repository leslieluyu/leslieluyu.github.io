To use L2 miss latency metric you will need to add the following line to <VTune install dir>/config/sampling/knl_matrix_db.txt
Note: Spaces below are tabs
Null    L2_MISS 0x1981F8        0,1     tbd


## Disable TRACING/PROFILING/DEBUGGING/STATS
run on baremetal, and will add them back later
## Remove resource limitation
To maximum the cpu utilization on baremetal

#!/bin/bash

pkill locust


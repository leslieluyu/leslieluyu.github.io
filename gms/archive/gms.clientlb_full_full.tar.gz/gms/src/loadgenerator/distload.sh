set -x

WORKERS=5
USERS=1000
SPAWN=10
CSV=${CSV:-test}

# Run Locust in distributed mode
locust --host="http://${FRONTEND_ADDR}" --headless -u "${USERS:-10}" -r ${SPAWN} --master --logfile=master.log --csv=$CSV --step-load --s
tep-users 10 --step-time 120s  &
sleep 5

for (( i=1; i<=$WORKERS; i++ ));do
        echo "locust --worker --logfile=worker$i.log"
        locust --worker --logfile=worker$i.log &
done


## A few considerations for doing benchmarking
1. Client should be on separate node, and use same load generator tool as DSB.
So the locust load generator would be just there for reference.
2. Share metrics collection with DSB (sysstat - cpu/mem/disk/network, emon, perf, prometheus etc)
3. Share k8s deployment with DSB


## Scenarios
Baseline(Scale up pods):
1. One replica for each service by default
2. Remove resource limitations for pods, so the pod can scale up when workload is heavy
3. Run on 1 worker node and 3 worker nodes
4. CLX, ICX, AMD and ARM

Tuning A(scale out pods):
1. Limit pod resource to 1 CPU
2. Tune the replicas to achive max throughput

Tuning B:
1. Enable CPU manager
2. Assign services to nodes with different policies

## How to Run
0. Deploy a k8s cluster, refer to https://github.com/intel-sandbox/cloud.benchmarking.deployment/tree/main/k8s
1. git clone from https://github.com/intel-sandbox/GoogleMicroserviceDemo.git, from benchmarking branch  
    git clone https://github.com/intel-sandbox/GoogleMicroserviceDemo.git -b benchmarking
2. install skaffold. skaffold is used to help build and manage images, examples for x86 platform  
    curl -Lo skaffold https://storage.googleapis.com/skaffold/releases/latest/skaffold-linux-amd64 && \
    sudo install skaffold /usr/local/bin/
3. Build all the images  
    cd tools  
    ./build.sh <registryHostIP>  

4. Use helm to deploy, modify the helm/override.yaml file with following entries  
registryHost: <registryHostIP>:5000/  
namespace: test  
replicaCount: 50  

    cd helm  
    kubectl create ns test  
    ./helminstall.sh  

5. Run the wrk2 client in docker container  
copy wrk to /usr/bin, and run test.sh script under /client  
    cd wrk2  
    sh runwrkclient.sh  
    cp wrk /usr/bin  
    cd /client  
    sh test.sh <frontendsvcip>  
6. looptest.sh is to run test automatically and collect emon data from outside of the container  
Edit the hosts file to add workers nodes to collect emon data  
Modify the parameters (RPS) and run  
    ./looptest.sh <frontendsvcip>  
Test will run automatically, and collect 30 seconds emon data for each run.

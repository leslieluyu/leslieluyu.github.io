imgs="wrk-client adservice currencyservice emailservice paymentservice productcatalogservice shippingservice cartservice checkoutservice recommendationservice frontend loadgenerator"
localreg="10.0.1.47:5000"
for img in $imgs
do
    echo $img
    # docker pull ${localreg}/$img:baseline
    docker tag ${localreg}/$img:baseline dolpher/$img:arm64
    docker push dolpher/$img:arm64
    docker manifest create dolpher/$img:baseline dolpher/$img:x64 dolpher/$img:arm64
    docker manifest push dolpher/$img:baseline
done


#!/bin/bash

svc=${1:-frontend}
ns=${2:-test}

pods=`kubectl -n ${ns} get pods |grep $svc |awk '{print $1}'`

for pod in $pods
do
	echo $pod
	kubectl -n ${ns} exec -ti $pod -- sudo apt update && sudo apt install -y net-tools
	#kubectl -n ${ns} exec -ti $pod -- netstat -n |grep ESTABLISHED
done

kubectl delete deploy frontend
kubectl apply -f ../all.yaml

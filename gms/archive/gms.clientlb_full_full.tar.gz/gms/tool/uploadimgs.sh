#!/bin/bash

#
# This Scripts is an example of preparing docker registry, you should modify according to your own env
#
# The GMS docker images are saved at
# http://10.165.56.39/internal/gms/
# Get them and upload to a local registry for use
#
# Make sure you have local registry ready
# Refer to https://github.com/intel-sandbox/cloud.benchmarking.deployment
# docker run -d --name registry --restart=always -p 5000:5000 -v registry:/var/lib/registry registry:2
#
# $version is reserved for future version upgrade

localreg=${1:-"10.0.1.47:5000"}
version=${2:-""}
imgrepo="http://10.165.56.39/internal/gms/rc1"
imgs="adservice currencyservice emailservice paymentservice productcatalogservice shippingservice cartservice checkoutservice recommendationservice frontend"
oldreg="10.0.1.47:5000"

echo "Uploading images to local registry ${localreg}"

echo "wrk-client"
if [ ! -f wrkclient.tar.gz ]; then
    curl -o wrkclient.tar.gz ${imgrepo}/wrkclient.tar.gz
fi
docker load < wrkclient.tar.gz
docker tag ${oldreg}/wrk-client:baseline ${localreg}/wrk-client:baseline
docker push ${localreg}/wrk-client:baseline

for img in $imgs
do
    echo $img
#    mkdir -p arm64
#    pushd arm64
#    if [ ! -f $img.tar.gz ]; then
#        curl -q -o $img.tar.gz ${imgrepo}/arm64$version/$img.tar.gz
#    fi
#    docker load < $img.tar.gz
#    docker tag ${oldreg}/$img:arm64$version ${localreg}/$img:arm64$version
#    docker push ${localreg}/$img:arm64$version
#    popd

    mkdir -p x64
    pushd x64
    if [ ! -f $img.tar.gz ]; then
        curl -q -o $img.tar.gz ${imgrepo}/x64$version/$img.tar.gz
    fi
    docker load < $img.tar.gz
    docker tag ${oldreg}/$img:x64$version ${localreg}/$img:x64$version
    docker push ${localreg}/$img:x64$version
    popd
    #mkdir x64
    #docker save ${localreg}/$img:x64 | gzip > x64/$img.tar.gz
    #docker manifest create dolpher/$img:baseline dolpher/$img:x64 dolpher/$img:arm64
    #docker manifest push dolpher/$img:baseline
done


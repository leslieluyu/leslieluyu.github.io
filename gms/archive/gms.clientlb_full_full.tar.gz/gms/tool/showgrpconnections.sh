#!/bin/bash

svc=${1:-frontend}
ns=${2:-gms}

pods=`kubectl -n ${ns} get pods |grep $svc |awk '{print $1}'`

for pod in $pods
do
	echo $pod
	kubectl -n ${ns} exec -ti $pod -- netstat -n |grep ESTABLISHED |wc -l
	#kubectl -n ${ns} exec -ti $pod -- netstat -n |grep ESTABLISHED
done

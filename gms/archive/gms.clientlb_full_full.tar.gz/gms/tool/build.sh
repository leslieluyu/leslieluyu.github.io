
function isx64dockerfile
{
 grep amd64 ../src/adservice/Dockerfile >/dev/null
}
function switchdockerfile
{
  TO=$1
  for SVC in $SVCS
  do
    echo $SVC
    cp ../src/${SVC}/Dockerfile.$TO ../src/${SVC}/Dockerfile
  done
}
function preparedockerfile
{
if [[ ${ARCH} == "x86_64" ]];then
  echo "x64"
  if isx64dockerfile;then
    echo "No change"
  else
    echo "Switch to x64"
    switchdockerfile x64
  fi
else
  echo "arm"
  if isx64dockerfile;then
    echo "Switch to arm64"
    switchdockerfile arm64
  else
    echo "No change"
  fi
fi

}

SVCS="adservice \
cartservice \
checkoutservice \
currencyservice \
emailservice \
frontend \
paymentservice \
productcatalogservice \
recommendationservice \
shippingservice \
loadgenerator"

ARCH=$(uname -p)
#ARCH=aarch64
#IP=$(ip route get 1 | awk '{match($0, /.+src\s([.0-9]+)/, a);print a[1];exit}')
# IP=$(ip route get 1 | awk '{print $7}')
IP=${1:-172.16.1.7}
TAG=${2:-x64}
# Setup the dockerfile for target platform
#cd $(dirname $0)/
echo "current DIR=$(pwd)"

preparedockerfile

cd ..
echo "current DIR=$(pwd)"
skaffold config set default-repo $IP:5000
skaffold build -t $TAG --build-concurrency=0

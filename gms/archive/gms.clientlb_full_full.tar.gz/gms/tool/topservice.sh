
svc=$1
pids=`ps -ef |grep ${svc} |grep -v grep |awk 'BEGIN { pid=""} {pid=$2","pid} END {print pid}' |head -c-2`
top -p $pids

imgs="adservice currencyservice emailservice paymentservice productcatalogservice shippingservice cartservice checkoutservice recommendationservice frontend"
localreg="10.0.1.47:5000"
for img in $imgs
do
    echo $img
    mkdir arm64
    docker save ${localreg}/$img:arm64 | gzip > arm64/$img.tar.gz
    mkdir x64
    docker save ${localreg}/$img:x64 | gzip > x64/$img.tar.gz
    #docker manifest create dolpher/$img:baseline dolpher/$img:x64 dolpher/$img:arm64
    #docker manifest push dolpher/$img:baseline
done


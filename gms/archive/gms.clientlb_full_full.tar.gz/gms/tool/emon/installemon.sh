echo "This is instruction, can't run"
exit 0
# Download the latest version from https://intel.sharepoint.com/sites/performance-tools
# and saved as sep-xxxx.tar.bz2

# Install kernel source
# For Ubuntu
kerver=`uname -r`
sudo apt install linux-headers-${kerver}
tar xvjf sep_private_5_24_linux_0219170677e3a80.tar.bz2

# Install
cd sep_*
./sep-installer.sh

# To use
source /opt/intel/sep/sep_vars.sh
./runemon.sh Testname

# process emon data
# modify a few vars
# Please collect emon data with -v command to avoid errors in post processing
# Fix the path for EDP ruby script and processor specific EDP files
#EDPRB=<fix-path>/edp.rb
#METRICS=<fix-path>/skx-2s.xml
#CHART_FORMAT=<fix-path>/chart_format_skx_2s.txt
# fix the path for the EMON input files
#EMON_DATA=<fix-emon-files-path>/emon.dat
#QPI=6.4
#jruby -j $EMON_V -k $EMON_M
/opt/intel/sep/config/edp/process.sh

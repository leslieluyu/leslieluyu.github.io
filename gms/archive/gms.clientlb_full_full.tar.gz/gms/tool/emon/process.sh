#!/bin/bash
####################################################################################
# EDP script to post process emon data in linux, generates a bunch of csv's
# prerequisites:
#	Install oracle-java8-installer
#	sudo -E apt-get install ruby jruby
#	sudo -E jruby -S gem install jruby-win32ole <optional>
#####################################################################################

ARCH_FOLDER='ArchitectureSpecific/Skylake/SKX-2S'

CWD=`dirname $0`
cp "${CWD}/edp.rb" $1
cp "${CWD}/${ARCH_FOLDER}"/skx-2s.xml $1
cp "${CWD}/${ARCH_FOLDER}"/chart_format_skx_2s.txt $1
cd $1
# Please collect emon data with -v command to avoid errors in post processing
# Fix the path for EDP ruby script and processor specific EDP files
EDPRB='edp.rb'
METRICS='skx-2s.xml'
CHART_FORMAT='chart_format_skx_2s.txt'

# fix the path for the EMON input files
EMON_DATA='/home/ubuntu/gmsemon/nocpin/emon.dat'
# ************** EMON -v and -M files need not be collected separately. EMON collection script adds -v parameter
# which adds version and topology information to EMON_DATA specified above. So leave the following commented out
#EMON_V=<fix-emon-files-path>/emon-v.dat
#EMON_M=<fix-emon-files-path>/emon-m.dat
OUTPUT=summary.xlsx

CPUS=`grep -c ^processor /proc/cpuinfo`
THREADS=$(( CPUS * 3 / 4 ))
FreeMEM=`free -m | head -2 | tail -1 | awk '{ print $4 }'`
FreeMEM=$(( $FreeMEM - 1024 ))
#echo Usable $THREADS threads with $FreeMEM MB memory.

JRUBY_OPTIONS="--server -J-Xmx${FreeMEM}m -J-Xms${FreeMEM}m --1.8"
PARALLELISM=$THREADS
#set TSC_FREQ=
#set TPS
# TPS=$2

BEGIN=1
END=100000
QPI=10.4

VIEW="--socket-view --thread-view"
#VIEW="--socket-view --core-view --thread-view"
#VIEW=""

#TIMESTAMP_IN_CHART="--timestamp-in-chart"
TIMESTAMP_IN_CHART=""

echo Starting to parallel process the EDP data at `date +"%d-%b-%Y %r"`

#echo "jruby $JRUBY_OPTIONS $EDPRB -i $EMON_DATA -j $EMON_V -k $EMON_M -f $CHART_FORMAT -o $OUTPUT -m $METRICS -b $BEGIN -e $END -q $QPI $VIEW -p $PARALLELISM"
#jruby $JRUBY_OPTIONS $EDPRB -i $EMON_DATA -f $CHART_FORMAT -o $OUTPUT -m $METRICS -b $BEGIN -e $END -q $QPI $VIEW -p $PARALLELISM
jruby $JRUBY_OPTIONS $EDPRB -i $EMON_DATA -f "${CHART_FORMAT}" -m "${METRICS}" -b $BEGIN -e $END -q $QPI $VIEW -p $PARALLELISM
echo Finished parallel processing the EDP data at `date +"%d-%b-%Y %r"`

exit


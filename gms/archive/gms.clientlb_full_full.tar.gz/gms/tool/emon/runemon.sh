#!/bin/bash


out=${1:-out}
mkdir -p $out
source /opt/intel/sep/sep_vars.sh
emon -v > ${out}/emon-v.dat
emon -M > ${out}/emon-M.dat
emon -i skylake_server_events_private.txt > ${out}/emon.dat & sleep 120

emon -stop


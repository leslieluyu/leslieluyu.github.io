REPLICA=${1:-1}
for i in {1..3}
do
    helm install --wait gms${i} ./gms${i} -f override.yaml --set replicaCount=${REPLICA}
    sleep 20
done


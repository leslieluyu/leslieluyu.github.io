helm delete gms3
helm delete gms2
helm delete gms1

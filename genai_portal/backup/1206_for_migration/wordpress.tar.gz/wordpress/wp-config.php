<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress_8399' );

/** Database username */
define( 'DB_USER', 'wordpress' );

/** Database password */
define( 'DB_PASSWORD', 'wordpress' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '9_~SB8zR0F2:%.G-HIDbZg&]%Z(I~H~<Y)Ll{ifj]eME;.s)L;G.Vgz6Q@h@PqaL' );
define( 'SECURE_AUTH_KEY',  '(u;Rlwur1A}#p+<EE-vK.rx)Y)Dj(?Ih|CWXig]hE~C.{X6$`HYxi@VG+di1*5CZ' );
define( 'LOGGED_IN_KEY',    'lQ&:d%r0JS.;tw<f:)Qv1H?P~7&6noUsKrjoZL)le.thri3gh{^.,v.{jP7e3j:g' );
define( 'NONCE_KEY',        '6?95hM4=E_PDNeL.^^:)wnId_5xBmW}6-w/J17W{gxYMhaDwylzK0n7=Z[pvh}#!' );
define( 'AUTH_SALT',        '-3Pkl]px>FCQumqiP(T]P&7mnG6xeZgd_ qCWxf7<v>,acupYW[:hxC]:o)cJ]^p' );
define( 'SECURE_AUTH_SALT', '>]eom;U|udEv1|RIbA,;Z$dKNX0D/)XY|BdrMK9K}%s3gWt[Rkt/#:VW[2& #+oF' );
define( 'LOGGED_IN_SALT',   'Q]fLQ$<RUs~$nI~}@&?>MSjoHf?O-+:3 9^2Ok|q?Zg033uO^_~[<^]UMoarpN2@' );
define( 'NONCE_SALT',       'QirP;,V&h3-)0D;LpJ9JI-wtFT7wVVdE#,RsPq{mS7N};H!6[Q:uk7jwR%J~+im!' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';


sudo yum install -y redsocks-0.4+dfsg-3.x86_64.rpm
sudo adduser --system --home /var/run/redsocks --no-create-home -U redsocks
sudo yum install -y autossh

#!/bin/bash
set -x

UBUNTU_VER=`lsb_release -c -s`
# replace the apt source with local mirror
#sudo sed -i "s|nova.clouds.archive.ubuntu.com|$LOCAL_APT_SRC|" /etc/apt/sources.list
#sudo sed -i "s|security.ubuntu.com|$LOCAL_APT_SRC|" /etc/apt/sources.list
# sudo sed -i 's|nova.clouds.archive.ubuntu.com|shtaurus.sh.intel.com|' /etc/apt/sources.list
# sudo sed -i 's|security.ubuntu.com|shtaurus.sh.intel.com|' /etc/apt/sources.list

# backup the old sources.list file
sudo cp /etc/apt/sources.list /etc/apt/sources.list.bak.`date +%M`

sudo -E tee /etc/apt/sources.list >>/dev/null << EOF
deb http://$LOCAL_APT_SRC/ubuntu/ ${UBUNTU_VER} main universe
deb http://$LOCAL_APT_SRC/ubuntu/ ${UBUNTU_VER}-updates main universe
deb http://$LOCAL_APT_SRC/ubuntu/ ${UBUNTU_VER}-backports main universe
deb http://$LOCAL_APT_SRC/ubuntu/ ${UBUNTU_VER}-security main universe
EOF
sudo apt update -y
# sudo apt install -y libvirt-bin

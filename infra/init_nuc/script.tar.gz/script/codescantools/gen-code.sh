#!/bin/bash
# set -x

DIRECT=nova-code
i=1
while read -r commit
do
    echo "$commit to patch $i"
    git show $commit |grep "^+" |sed 's/^+//g' > $DIRECT/patch$i.py
    let i++
done < commits

#!/bin/bash
set -x
PROJECT=${1:-openstackcore-cyborg}
COMMIT=${2:-033b0af1f72a8fa0056c839819de22bbe79e374c}

mkdir ${PROJECT}-changed
cd $PROJECT
git diff --name-only $COMMIT > changedfiles

while read -r onefile
do
    echo "$onefile changed"
    cp --parents $onefile ../${PROJECT}-changed/
done < changedfiles


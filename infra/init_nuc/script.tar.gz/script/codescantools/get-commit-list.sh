git log --author intel.com |grep commit |awk '{print $2}'

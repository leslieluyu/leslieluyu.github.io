#!/bin/bash

source environment.inc
set -x

# Setup common environment for intel network
./vm-setup.sh
# Using local git cache
./prep.sh
# Generate local.conf and run devstack
./run-devstack.sh

# If enabled live migration, run this
cd $TOPDIR
./lm-prep.sh

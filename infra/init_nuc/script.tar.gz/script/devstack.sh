#!/bin/bash

source environment.inc
set -x

./prep.sh
./run-devstack.sh

cd $TOPDIR
./lm-prep.sh

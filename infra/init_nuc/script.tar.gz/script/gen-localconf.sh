#!/bin/bash
set -x
MY_IP=($ip route get 1 | awk '{match($0, /.+src\s([.0-9]+)/, a);print a[1];exit}')
# Generate the local.conf file
if [ $MY_IP == $CTRL_IP ]; then
cat > local.conf << EOF
[[local|localrc]]
# settings for local env
NOVNC_REPO=$LOCAL_CACHE/kanaka/noVNC.git
GIT_BASE=$LOCAL_CACHE
IMAGE_URLS=file://$LOCAL_CACHE/images/cirros-0.3.5-x86_64-disk.img
DOWNLOAD_DEFAULT_IMAGES=False
# Multihost settings
MULTI_HOST=True
HOST_IP=$MY_IP
SERVICE_HOST=$CTRL_IP
DATABASE_TYPE=mysql
MYSQL_HOST=$CTRL_IP
RABBIT_HOST=$CTRL_IP

DATABASE_PASSWORD=123
ADMIN_PASSWORD=123
MYSQL_PASSWORD=123
RABBIT_PASSWORD=123
SERVICE_PASSWORD=123
SERVICE_TOKEN=ADMIN

FIXED_RANGE=192.168.128.0/24
IPV4_ADDRS_SAFE_TO_USE=192.168.128.0/24

disable_service n-net
disable_service tempest
disable_service heat
enable_service q-svc
enable_service q-agt
enable_service q-dhcp
enable_service q-l3
enable_service q-meta
enable_service quantum
enable_service n-novnc

NOVA_VNC_ENABLED=True
NOVNCPROXY_URL="http://$CTRL_IP:6080/vnc_auto.html"
VNCSERVER_LISTEN=0.0.0.0
VNCSERVER_PROXYCLIENT_ADDRESS=$CTRL_IP

RECLONE=False
#enable Logging
LOGFILE=/opt/stack/logs/stack.sh.log
VERBOSE=True
LOG_COLOR=True
LOGDIR=/opt/stack/logs
EOF
else
cat > local.conf << EOF
[[local|localrc]]
# settings for local env
NOVNC_REPO=$LOCAL_CACHE/kanaka/noVNC.git
GIT_BASE=$LOCAL_CACHE
IMAGE_URLS=file://$LOCAL_CACHE/images/cirros-0.3.5-x86_64-disk.img
DOWNLOAD_DEFAULT_IMAGES=False
# Multihost settings
MULTI_HOST=True
HOST_IP=$MY_IP
SERVICE_HOST=$CTRL_IP
DATABASE_TYPE=mysql
MYSQL_HOST=$CTRL_IP
RABBIT_HOST=$CTRL_IP

DATABASE_PASSWORD=123
ADMIN_PASSWORD=123
MYSQL_PASSWORD=123
RABBIT_PASSWORD=123
SERVICE_PASSWORD=123
SERVICE_TOKEN=ADMIN

FIXED_RANGE=192.168.128.0/24
IPV4_ADDRS_SAFE_TO_USE=192.168.128.0/24

ENABLED_SERVICES=n-cpu,q-agt,n-meta-api,placement-client

NOVA_VNC_ENABLED=True
NOVNCPROXY_URL="http://$CTRL_IP:6080/vnc_auto.html"
VNCSERVER_LISTEN=0.0.0.0
VNCSERVER_PROXYCLIENT_ADDRESS=$CTRL_IP

RECLONE=False
#enable Logging
LOGFILE=/opt/stack/logs/stack.sh.log
VERBOSE=True
LOG_COLOR=True
LOGDIR=/opt/stack/logs
EOF
fi

#!/bin/bash

HOSTNAME="otc-disteng.ostc.intel.com"
ALTHOST="superman"
if [ "x$HOME" != "x" ]; then
    echo $HOME
else
    echo "Empty HOME, setting as /root"
    HOME="/root"
fi
HOST="
Host $HOSTNAME
    StrictHostKeyChecking no
    User rzang
    IdentityFile ~/.ssh/id_rsa.team

Host $ALTHOST
    HostName ${ALTHOST}.sc.intel.com
    StrictHostKeyChecking no
    User eos
    IdentityFile ~/.ssh/id_rsa.team"

DIR_SSH="$HOME/.ssh"


if [ ! -d $DIR_SSH ]; then
    echo "create "$DIR_SSH
    mkdir $DIR_SSH 
fi

if [ ! -f $DIR_SSH/id_rsa.team ]; then
    echo "create "$DIR_SSH/id_rsa.team
    cp id_rsa.team $DIR_SSH/id_rsa.team
fi
chmod 0600 $DIR_SSH/id_rsa.team 


if [ ! -f $DIR_SSH/config ]; then
    echo "touch $DIR_SSH/config"
    touch $DIR_SSH/config
    chmod 600 $DIR_SSH/config
fi
ACTIVEHOST=$ALTHOST
IS_HOST=`grep $ACTIVEHOST $DIR_SSH/config`
if [ -z "$IS_HOST" ]; then
    echo "config $ACTIVEHOST"
    echo -e "$HOST" >> $DIR_SSH/config
fi

PID=`ps -ef |grep autossh.*$ACTIVEHOST |grep -v grep |awk '{print $2}'`
echo "kill the process $PID"
sudo kill -9 $PID

autossh -f -M 0 -N -L 127.0.0.1:1080:proxy.jf.intel.com:1080 $ACTIVEHOST

# Add to rc.local
grep -q $ACTIVEHOST /etc/rc.local
if [ $? != 0 ]; then
    #sudo sed -i "/^exit 0$/i su $USER -c \"/usr/bin/autossh -f -M 0 -N -L 127.0.0.1:1080:proxy.jf.intel.com:1080 $ACTIVEHOST\"" /etc/rc.local
    echo "/usr/bin/autossh -f -M 0 -N -L 127.0.0.1:1080:proxy.jf.intel.com:1080 $ACTIVEHOST" > ~/autossh.sh
fi


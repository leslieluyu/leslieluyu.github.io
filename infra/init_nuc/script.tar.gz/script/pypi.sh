#!/bin/bash
set -x
# replace pypi local mirror globally

#PIP_CONF=/etc/pip.conf
PYTHON_BIN=/usr/bin/python

#sudo tee $PIP_CONF << EOF
#[global]
#index-url = http://$LOCAL_PYPI
#trusted-host = $PYPI_HOST
#extra-index-url=https://pypi.python.org/simple/
#EOF

if [[ ! -e $PYTHON_BIN ]]; then
    # ubuntu 16.04 seems don't install python
    # PYTHON_BIN=/usr/bin/python3
    sudo apt install python
fi

sudo "${PYTHON_BIN}" get-pip.py

echo "Done\n"
